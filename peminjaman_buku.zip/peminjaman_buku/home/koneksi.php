<?php 
$host = "localhost";
$user = "root";
$pass = "";
$db = "peminjaman_buku";

$koneksi = New mysqli($host, $user, $pass, $db);
?>